#include <task.h>

void
taskmain(int argc, char *argv[])
{
	taskdelay(1000);
}
